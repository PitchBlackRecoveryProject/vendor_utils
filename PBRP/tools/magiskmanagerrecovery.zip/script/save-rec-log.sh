#!/sbin/sh

cp -f /tmp/recovery.log /sdcard/